# func_from.py
from lib.funcdef import square, cube

print(square(10))
print(cube(10))
