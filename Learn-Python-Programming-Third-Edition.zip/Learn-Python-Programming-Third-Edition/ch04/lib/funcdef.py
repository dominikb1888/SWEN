# lib/funcdef.py
def square(n):
    return n ** 2

def cube(n):
    return n ** 3
