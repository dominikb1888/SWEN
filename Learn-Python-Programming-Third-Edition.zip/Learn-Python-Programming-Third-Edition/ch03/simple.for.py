for number in [0, 1, 2, 3, 4]:
    print(number)


# equivalent using range
for number in range(5):
    print(number)
