def hello():
    return "Hello, World"


def name(student):
    return hello() + student


print(name("Marina"))

# Hello, WorldMarina

# print(hello() + student)
# print(hello() + "Marina")
# print("Hello, World" + "Marina")
# print("Hello, WorldMarina")
# >>> Hello, WorldMarina
