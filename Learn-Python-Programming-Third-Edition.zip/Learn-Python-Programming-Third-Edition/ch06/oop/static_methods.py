# oop/static.methods.py
class StringUtil:
    def __init__(self, sentence):
        self.sentence = sentence

    def is_palindrome(self, case_insensitive=True):
        # we allow only letters and numbers
        s = "".join(c for c in self.sentence if c.isalnum())  # Study this!
        # For case insensitive comparison, we lower-case s
        if case_insensitive:
            s = s.lower()
        for c in range(len(s) // 2):
            if s[c] != s[-c - 1]:
                return False
        return True

    def get_unique_words(self):
        return set(self.sentence.split())
