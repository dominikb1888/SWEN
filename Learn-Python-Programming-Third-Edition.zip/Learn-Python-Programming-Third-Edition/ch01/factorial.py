>>> from math import factorial
>>> factorial(5)
120