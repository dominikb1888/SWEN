#!/bin/sh

# start a simple HTTP Server
python -m http.server 8000
