# train-project/setup.py
import setuptools

setuptools.setup()
